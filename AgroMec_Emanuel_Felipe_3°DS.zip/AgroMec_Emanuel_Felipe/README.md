# AgroMec — Gestão de Manutenção de Máquinas Agrícolas

Projeto do Simulado Prático SAEP — SESI SENAI — Técnico em Desenvolvimento de Sistemas — 3º ano.

## Tecnologias
Python 3.11+, Flask 3.1.2, SQLite, HTML/CSS/JavaScript e pytest.

## Como executar
```bash
python -m venv venv
# Windows: venv\\Scripts\\activate
# Linux: source venv/bin/activate
pip install -r requirements.txt
python src/app.py
```
Acesse http://127.0.0.1:5000.

**Login:** gerente | **Senha:** Saep@2026

## RF01–RF11
RF01 Feito; RF02 Feito; RF03 Feito; RF04 Feito; RF05 Feito; RF06 Feito; RF07 Feito; RF08 Feito; RF09 Feito; RF10 Feito; RF11 Feito.

## Regras
RN01–RN08 implementadas no backend. Senhas têm hash e as consultas usam parâmetros, sem concatenar entrada do usuário.

## Testes
`pytest -q`

## Documentação
`docs/01_modelagem.md`, `02_ddl.sql`, `03_dml.sql`, `04_consultas.sql`, `05_plano_de_testes.md`.

## Bônus
`simulador_sensor.py` envia leituras para `POST /api/horimetro`.

## Limitações
Para o laboratório foi usado SQLite pela portabilidade. O GRANT equivalente em MySQL está comentado no DDL. Evidências de execução (prints) devem ser capturadas no computador da prova, pois dependem do ambiente de execução.
